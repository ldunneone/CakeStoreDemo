package com.example.cakestore.models

class CakeResponse : ArrayList<JsonAPIItem>()