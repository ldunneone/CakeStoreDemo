package com.example.cakestore

interface CakeClick {
    fun onCakeClick(position: Int)
}