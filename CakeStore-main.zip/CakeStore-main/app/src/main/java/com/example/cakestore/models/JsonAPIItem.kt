package com.example.cakestore.models

data class JsonAPIItem(
    val desc: String,
    val image: String,
    val title: String
)